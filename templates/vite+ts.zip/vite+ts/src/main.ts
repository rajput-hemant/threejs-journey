import * as THREE from 'three'

import "./style.css";
