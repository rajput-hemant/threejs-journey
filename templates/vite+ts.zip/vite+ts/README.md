<div align="center">

# Vite + TS Template

#### Course: [ThreeJS Journey][course] By Bruno Simon

<!-----------------------------------{ Links }---------------------------------->

[course]: https://threejs-journey.com

</div>
