<div align="center">

# Vite + JS Template

#### Course: [ThreeJS Journey][course] By Bruno Simon

<!-----------------------------------{ Links }---------------------------------->

[course]: https://threejs-journey.com

</div>
